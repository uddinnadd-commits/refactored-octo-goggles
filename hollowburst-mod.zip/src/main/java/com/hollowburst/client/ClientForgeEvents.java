package com.hollowburst.client;

import com.hollowburst.HollowBurstMod;
import com.hollowburst.network.ActivatePacket;
import com.hollowburst.network.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = HollowBurstMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        CutscenePlayer.tick(mc);

        while (ClientKeys.ACTIVATE.consumeClick()) {
            if (mc.player == null || mc.screen != null || CutscenePlayer.inputLocked()) continue;
            try {
                Net.CHANNEL.send(new ActivatePacket(), PacketDistributor.SERVER.noArg());
            } catch (Exception ex) {
                HollowBurstMod.LOGGER.warn("Could not send Hollow Burst activation (server without the mod?)", ex);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        CutsceneRenderer.render(event.getGuiGraphics());
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        CutsceneDef def = CutscenePlayer.def();
        if (def == null || !event.usedConfiguredFov()) return;
        long t = CutscenePlayer.elapsedMs();
        event.setFOV(event.getFOV() * def.fov.applyAsDouble(t));
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        CutsceneDef def = CutscenePlayer.def();
        if (def == null) return;
        long ms = CutscenePlayer.elapsedMs();
        double t = ms * 0.001;
        double amp = def.shake.applyAsDouble(ms);

        float yaw = event.getYaw() + (float) (amp * (Math.sin(t * 53.0) + 0.5 * Math.sin(t * 97.0)));
        float pitch = event.getPitch() + (float) (amp * (Math.sin(t * 61.0 + 1.3) + 0.5 * Math.sin(t * 89.0)));
        float roll = event.getRoll()
                + (float) def.roll.applyAsDouble(ms)
                + (float) (amp * 0.6 * Math.sin(t * 71.0 + 2.1));

        event.setYaw(yaw);
        event.setPitch(pitch);
        event.setRoll(roll);
    }

    /** No walking, jumping or sneaking while the cutscene holds the player. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!CutscenePlayer.inputLocked()) return;
        Input in = event.getInput();
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.forwardImpulse = 0.0F;
        in.leftImpulse = 0.0F;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    /** No swinging or using items while the cutscene holds the player. */
    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (CutscenePlayer.inputLocked()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    private ClientForgeEvents() {}
}
