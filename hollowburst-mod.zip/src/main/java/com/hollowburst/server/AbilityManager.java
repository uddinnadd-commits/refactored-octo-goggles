package com.hollowburst.server;

import com.hollowburst.Config;
import com.hollowburst.CutsceneType;
import com.hollowburst.HollowBurstMod;
import com.hollowburst.network.CutscenePacket;
import com.hollowburst.network.Net;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server side of the mod: cooldowns, the explosion, the "primed" window after the launch,
 * and the three timed sequences (Red / Blue / Purple). All timing is in server ticks (20 / s).
 * The client plays a matching cutscene (letterbox, subtitles, impact frames) when told to.
 */
@Mod.EventBusSubscriber(modid = HollowBurstMod.MODID)
public final class AbilityManager {

    // ---------------------------------------------------------------- state

    private static final class PlayerState {
        int cooldownUntil;
        int primedUntil;      // sword / mace hit triggers a cutscene while now < primedUntil
        int launchTick = -1;
        int graceUntil = -1;  // set shortly after landing; primed state ends when it passes
        int protectUntil;     // no fall / explosion damage while now < protectUntil
        boolean sequenceActive;
    }

    private static final class Freeze {
        final LivingEntity entity;
        final boolean wasNoGravity;
        final boolean wasNoAi;
        boolean hold;
        int until;

        Freeze(LivingEntity entity, boolean wasNoGravity, boolean wasNoAi) {
            this.entity = entity;
            this.wasNoGravity = wasNoGravity;
            this.wasNoAi = wasNoAi;
        }
    }

    private record Task(int runAt, Runnable action) {}

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final Map<UUID, Freeze> FREEZES = new HashMap<>();
    private static final List<Task> TASKS = new ArrayList<>();

    private AbilityManager() {}

    private static PlayerState state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), k -> new PlayerState());
    }

    private static void schedule(int tick, Runnable action) {
        TASKS.add(new Task(tick, action));
    }

    private static void send(ServerPlayer p, CutsceneType type) {
        Net.CHANNEL.send(new CutscenePacket(type), PacketDistributor.PLAYER.with(p));
    }

    // ---------------------------------------------------------------- activation (C key)

    public static void tryActivate(ServerPlayer p) {
        if (!p.isAlive() || p.isSpectator()) return;
        MinecraftServer server = p.getServer();
        if (server == null) return;

        int now = server.getTickCount();
        PlayerState st = state(p);
        if (st.sequenceActive) return;

        if (now < st.cooldownUntil) {
            int secs = (st.cooldownUntil - now + 19) / 20;
            p.displayClientMessage(Component.translatable("message.hollowburst.cooldown", secs), true);
            return;
        }

        st.sequenceActive = true;
        st.cooldownUntil = now + 28 + Config.COOLDOWN_SECONDS.get() * 20;
        st.primedUntil = 0;
        st.launchTick = -1;
        st.graceUntil = -1;

        send(p, CutsceneType.BURST);
        freeze(p, now + 40, true);

        for (int i = 0; i < 24; i++) {
            final int step = i;
            schedule(now + i, () -> chargeBurst(p, step));
        }
        schedule(now + 10, () -> Fx.sound(p.serverLevel(), p.position(), "block.beacon.activate", 1.6f, 1.9f));
        schedule(now + 24, () -> detonate(p, st));
        schedule(now + 28, () -> st.sequenceActive = false);
    }

    private static void chargeBurst(ServerPlayer p, int step) {
        if (p.isRemoved() || !p.isAlive()) return;
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position().add(0, p.getBbHeight() * 0.55, 0);
        double r = 3.2 * (1.0 - step / 24.0) + 0.5;
        for (int k = 0; k < 10; k++) {
            Fx.one(l, Fx.RED, c.add(Fx.randomUnit(l.random).scale(r)));
        }
        if (step % 4 == 0) {
            Fx.burst(l, ParticleTypes.ELECTRIC_SPARK, c, 6, 0.5, 0.3);
        }
    }

    private static void detonate(ServerPlayer p, PlayerState st) {
        if (p.isRemoved() || !p.isAlive()) {
            st.sequenceActive = false;
            return;
        }
        ServerLevel l = p.serverLevel();
        int now = p.getServer().getTickCount();
        release(p);

        Vec3 pos = p.position();
        Vec3 chest = pos.add(0, p.getBbHeight() * 0.5, 0);

        if (Config.DESTROY_BLOCKS.get()) {
            st.protectUntil = Math.max(st.protectUntil, now + 80);
            l.explode(p, pos.x, pos.y, pos.z, 3.5F, Level.ExplosionInteraction.TNT);
        }

        // damage and knock back everything nearby
        DamageSource src = l.damageSources().playerAttack(p);
        for (LivingEntity e : victimsAround(p, chest, 7.0)) {
            Vec3 away = horizontal(e.position().subtract(pos));
            e.invulnerableTime = 0;
            e.hurt(src, Config.BURST_DAMAGE.get().floatValue());
            e.setDeltaMovement(away.x * 1.8, 0.7, away.z * 1.8);
            e.hurtMarked = true;
        }

        // the launch
        Vec3 look = p.getLookAngle();
        p.setDeltaMovement(look.x * 0.25, Config.LAUNCH_SPEED.get(), look.z * 0.25);
        p.hurtMarked = true;
        p.fallDistance = 0.0F;

        // effects
        Fx.sound(l, pos, "entity.generic.explode", 4.0f, 0.7f);
        Fx.sound(l, pos, "entity.warden.sonic_boom", 2.0f, 1.0f);
        Fx.sound(l, pos, "entity.lightning_bolt.thunder", 3.0f, 1.4f);
        Fx.burst(l, ParticleTypes.FLASH, chest, 2, 0.0, 0.0);
        Fx.burst(l, ParticleTypes.EXPLOSION_EMITTER, chest, 2, 1.2, 0.0);
        Fx.burst(l, Fx.RED_BIG, chest, 180, 2.2, 0.0);
        Fx.burst(l, ParticleTypes.FLAME, chest, 120, 0.8, 0.35);
        Fx.burst(l, ParticleTypes.SONIC_BOOM, chest, 1, 0.0, 0.0);
        Fx.ring(l, ParticleTypes.CLOUD, pos.add(0, 0.2, 0), 48, 0.9);
        Fx.ring(l, ParticleTypes.CLOUD, pos.add(0, 0.6, 0), 32, 1.5);

        // start the airborne window
        st.launchTick = now;
        st.primedUntil = now + Config.PRIMED_SECONDS.get() * 20;
        st.graceUntil = -1;
        st.protectUntil = Math.max(st.protectUntil, st.primedUntil + 200);
    }

    // ---------------------------------------------------------------- landing a hit

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        if (!(event.getTarget() instanceof LivingEntity target)) return;
        MinecraftServer server = p.getServer();
        if (server == null) return;

        PlayerState st = STATES.get(p.getUUID());
        if (st == null) return;
        int now = server.getTickCount();
        if (st.sequenceActive || st.primedUntil <= now) return;
        if (!isValidVictim(p, target)) return;

        ItemStack held = p.getMainHandItem();
        if (held.is(Items.MACE)) {
            startMace(p, target, st, now);
        } else if (held.is(ItemTags.SWORDS)) {
            startSword(p, target, st, now);
        }
    }

    // ---------------------------------------------------------------- SWORD: Lapse: Blue

    private static void startSword(ServerPlayer p, LivingEntity target, PlayerState st, int now) {
        st.sequenceActive = true;
        st.primedUntil = 0;
        st.protectUntil = Math.max(st.protectUntil, now + 160);
        send(p, CutsceneType.SWORD);

        final Vec3[] focus = { centerOf(target) };
        final List<LivingEntity> victims = victimsAround(p, focus[0], 9.0);
        if (!victims.contains(target)) victims.add(target);

        freeze(p, now + 70, true);
        for (LivingEntity e : victims) freeze(e, now + 45, false);

        for (int i = 0; i < 25; i++) {
            final int step = i;
            schedule(now + i, () -> swordPull(p, target, victims, focus, step));
        }
        schedule(now + 25, () -> {
            ServerLevel l = p.serverLevel();
            for (LivingEntity e : victims) freeze(e, now + 45, true);
            Fx.burst(l, ParticleTypes.FLASH, focus[0], 1, 0.0, 0.0);
            Fx.sound(l, focus[0], "entity.warden.sonic_boom", 1.4f, 1.5f);
        });
        schedule(now + 40, () -> swordSlash(p, target, victims, focus));
        schedule(now + 66, () -> release(p));
        schedule(now + 76, () -> st.sequenceActive = false);
    }

    private static void swordPull(ServerPlayer p, LivingEntity target, List<LivingEntity> victims, Vec3[] focus, int step) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        if (target.isAlive()) focus[0] = centerOf(target);
        Vec3 f = focus[0];

        for (LivingEntity e : victims) {
            if (e == target || e.isRemoved() || !e.isAlive()) continue;
            Vec3 d = f.subtract(centerOf(e));
            double dist = d.length();
            if (dist < 0.9) {
                e.setDeltaMovement(Vec3.ZERO);
            } else {
                e.setDeltaMovement(d.scale(1.0 / dist).scale(Math.min(1.1, 0.25 + dist * 0.25)));
            }
            e.hurtMarked = true;
        }

        for (int k = 0; k < 8; k++) {
            double a = step * 0.55 + k * (Math.PI * 2.0 / 8.0);
            double r = 4.2 * (1.0 - step / 25.0) + 0.35;
            double y = Math.sin(step * 0.4 + k) * r * 0.45;
            Fx.one(l, Fx.BLUE, f.add(Math.cos(a) * r, y, Math.sin(a) * r));
        }
        Fx.burst(l, Fx.BLUE_BIG, f, 3, 0.25, 0.0);
        if (step == 0) Fx.sound(l, f, "block.beacon.activate", 2.0f, 0.8f);
        if (step == 12) Fx.sound(l, f, "entity.enderman.teleport", 2.0f, 0.5f);
    }

    private static void swordSlash(ServerPlayer p, LivingEntity target, List<LivingEntity> victims, Vec3[] focus) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        if (target.isAlive()) focus[0] = centerOf(target);
        Vec3 f = focus[0];

        for (LivingEntity e : victims) release(e);

        DamageSource src = l.damageSources().playerAttack(p);
        float base = Config.SWORD_DAMAGE.get().floatValue();
        for (LivingEntity e : victims) {
            if (e.isRemoved() || !e.isAlive()) continue;
            Vec3 away = horizontal(e.position().subtract(p.position()));
            e.invulnerableTime = 0;
            e.hurt(src, e == target ? base : base * 0.35f);
            e.setDeltaMovement(away.x * 1.5, 0.45, away.z * 1.5);
            e.hurtMarked = true;
        }

        // two crossing slashes made of particles
        Vec3 dir = horizontal(f.subtract(p.position()));
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        for (double t = -3.5; t <= 3.5; t += 0.25) {
            Vec3 a = f.add(side.scale(t)).add(0, t * 0.6, 0);
            Vec3 b = f.add(side.scale(t)).add(0, -t * 0.6, 0);
            Fx.one(l, Fx.BLUE_BIG, a);
            Fx.one(l, Fx.BLUE_BIG, b);
            Fx.one(l, ParticleTypes.END_ROD, a);
            Fx.one(l, ParticleTypes.END_ROD, b);
        }
        Fx.burst(l, ParticleTypes.SWEEP_ATTACK, f, 9, 1.4, 0.0);
        Fx.burst(l, ParticleTypes.CRIT, f, 80, 1.0, 0.6);
        Fx.burst(l, Fx.BLUE_BIG, f, 120, 1.6, 0.0);
        Fx.burst(l, ParticleTypes.FLASH, f, 1, 0.0, 0.0);
        Fx.ring(l, ParticleTypes.CLOUD, f, 36, 1.0);

        Fx.sound(l, f, "entity.player.attack.sweep", 3.0f, 0.8f);
        Fx.sound(l, f, "entity.player.attack.crit", 3.0f, 0.7f);
        Fx.sound(l, f, "entity.lightning_bolt.impact", 2.0f, 1.2f);
    }

    // ---------------------------------------------------------------- MACE: Hollow Purple

    private static void startMace(ServerPlayer p, LivingEntity target, PlayerState st, int now) {
        st.sequenceActive = true;
        st.primedUntil = 0;
        st.protectUntil = Math.max(st.protectUntil, now + 220);
        send(p, CutsceneType.MACE);

        final Vec3[] focus = { centerOf(target) };
        final List<LivingEntity> victims = victimsAround(p, focus[0], 12.0);
        if (!victims.contains(target)) victims.add(target);

        // time stop
        freeze(p, now + 110, true);
        for (LivingEntity e : victims) freeze(e, now + 90, true);

        Vec3 eye = p.getEyePosition();
        Vec3 axis = focus[0].subtract(eye);
        double len = axis.length();
        final Vec3 axisN = len < 1.0E-3 ? p.getLookAngle() : axis.scale(1.0 / len);
        final Vec3 orbC = eye.add(axisN.scale(Math.max(1.6, Math.min(len * 0.5, 3.0))));
        Vec3 ref = Math.abs(axisN.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        final Vec3 u = axisN.cross(ref).normalize();
        final Vec3 v = axisN.cross(u).normalize();

        for (int i = 0; i < 60; i++) {
            final int step = i;
            schedule(now + i, () -> maceCharge(p, orbC, u, v, step));
        }
        schedule(now + 60, () -> maceMerge(p, orbC));
        for (int i = 0; i < 18; i++) {
            final int step = i;
            schedule(now + 60 + i, () -> maceFly(p, orbC, focus, step));
        }
        schedule(now + 78, () -> maceImpact(p, target, victims, focus));
        schedule(now + 84, () -> maceAftershock(p, focus));
        schedule(now + 100, () -> release(p));
        schedule(now + 118, () -> st.sequenceActive = false);
    }

    private static void maceCharge(ServerPlayer p, Vec3 c, Vec3 u, Vec3 v, int step) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        double a = step * 0.42;
        double r = 1.5 * (1.0 - step / 60.0) + 0.12;
        Vec3 off = u.scale(Math.cos(a) * r).add(v.scale(Math.sin(a) * r));
        Vec3 trail = u.scale(Math.cos(a - 0.3) * r).add(v.scale(Math.sin(a - 0.3) * r));
        Fx.one(l, Fx.RED_BIG, c.add(off));
        Fx.one(l, Fx.BLUE_BIG, c.subtract(off));
        Fx.one(l, Fx.RED, c.add(trail));
        Fx.one(l, Fx.BLUE, c.subtract(trail));
        Fx.burst(l, ParticleTypes.ELECTRIC_SPARK, c, 1, 0.3, 0.05);
        if (step == 0) Fx.sound(l, c, "block.beacon.power_select", 2.0f, 0.7f);
        if (step == 40) Fx.sound(l, c, "entity.ender_dragon.growl", 1.2f, 0.5f);
    }

    private static void maceMerge(ServerPlayer p, Vec3 c) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        Fx.burst(l, ParticleTypes.FLASH, c, 2, 0.0, 0.0);
        Fx.burst(l, ParticleTypes.PORTAL, c, 120, 0.6, 1.0);
        Fx.burst(l, Fx.PURPLE_BIG, c, 80, 0.5, 0.0);
        Fx.sound(l, c, "block.beacon.activate", 3.0f, 0.5f);
        Fx.sound(l, c, "entity.warden.sonic_boom", 2.0f, 0.7f);
    }

    private static void maceFly(ServerPlayer p, Vec3 orbC, Vec3[] focus, int step) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        Vec3 pos = orbC.add(focus[0].subtract(orbC).scale((step + 1) / 18.0));
        Fx.burst(l, Fx.PURPLE_BIG, pos, 4, 0.35, 0.0);
        for (int k = 0; k < 10; k++) {
            Fx.one(l, Fx.PURPLE, pos.add(Fx.randomUnit(l.random).scale(0.9)));
        }
        Fx.burst(l, ParticleTypes.REVERSE_PORTAL, pos, 6, 0.4, 0.1);
        Fx.burst(l, ParticleTypes.WITCH, pos, 4, 0.4, 0.0);
        if (step == 0) Fx.sound(l, pos, "entity.wither.shoot", 2.0f, 0.5f);
    }

    private static void maceImpact(ServerPlayer p, LivingEntity target, List<LivingEntity> victims, Vec3[] focus) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        if (target.isAlive()) focus[0] = centerOf(target);
        Vec3 f = focus[0];

        for (LivingEntity e : victims) release(e);

        if (Config.DESTROY_BLOCKS.get()) {
            l.explode(p, f.x, f.y, f.z, 6.0F, Level.ExplosionInteraction.TNT);
        }

        DamageSource src = l.damageSources().playerAttack(p);
        float base = Config.MACE_DAMAGE.get().floatValue();
        for (LivingEntity e : victims) {
            if (e.isRemoved() || !e.isAlive()) continue;
            Vec3 away = horizontal(e.position().subtract(f));
            e.invulnerableTime = 0;
            e.hurt(src, e == target ? base : base * 0.5f);
            e.setDeltaMovement(away.x * 2.4, 1.1, away.z * 2.4);
            e.hurtMarked = true;
        }

        Fx.burst(l, ParticleTypes.FLASH, f, 3, 0.0, 0.0);
        Fx.burst(l, ParticleTypes.EXPLOSION_EMITTER, f, 8, 3.0, 0.0);
        Fx.burst(l, Fx.PURPLE_BIG, f, 400, 3.5, 0.0);
        Fx.burst(l, ParticleTypes.PORTAL, f, 300, 3.0, 1.2);
        Fx.burst(l, ParticleTypes.REVERSE_PORTAL, f, 200, 2.5, 0.8);
        Fx.burst(l, ParticleTypes.END_ROD, f, 120, 2.0, 0.9);
        Fx.burst(l, ParticleTypes.SONIC_BOOM, f, 1, 0.0, 0.0);
        Fx.ring(l, ParticleTypes.CLOUD, f, 64, 1.2);
        Fx.ring(l, ParticleTypes.CLOUD, f.add(0, 0.8, 0), 48, 2.0);

        Fx.sound(l, f, "entity.generic.explode", 5.0f, 0.5f);
        Fx.sound(l, f, "entity.warden.sonic_boom", 3.0f, 0.5f);
        Fx.sound(l, f, "entity.lightning_bolt.thunder", 4.0f, 0.6f);
        Fx.sound(l, f, "item.mace.smash_ground_heavy", 4.0f, 0.8f);
    }

    private static void maceAftershock(ServerPlayer p, Vec3[] focus) {
        if (p.isRemoved()) return;
        ServerLevel l = p.serverLevel();
        Fx.ring(l, ParticleTypes.CLOUD, focus[0], 64, 1.8);
        Fx.burst(l, Fx.PURPLE_BIG, focus[0], 150, 4.5, 0.0);
        Fx.sound(l, focus[0], "entity.generic.explode", 3.0f, 0.4f);
    }

    // ---------------------------------------------------------------- freezing ("time stop")

    private static void freeze(LivingEntity e, int until, boolean hold) {
        Freeze f = FREEZES.get(e.getUUID());
        if (f == null) {
            boolean ai = false;
            if (e instanceof Mob mob) ai = mob.isNoAi();
            f = new Freeze(e, e.isNoGravity(), ai);
            FREEZES.put(e.getUUID(), f);
            e.setNoGravity(true);
            if (e instanceof Mob mob2) mob2.setNoAi(true);
        }
        f.until = Math.max(f.until, until);
        f.hold = f.hold || hold;
    }

    private static void release(LivingEntity e) {
        Freeze f = FREEZES.remove(e.getUUID());
        if (f == null) return;
        restore(f);
    }

    private static void restore(Freeze f) {
        LivingEntity e = f.entity;
        e.setNoGravity(f.wasNoGravity);
        if (e instanceof Mob mob) mob.setNoAi(f.wasNoAi);
    }

    private static void tickFreezes(int now) {
        if (FREEZES.isEmpty()) return;
        Iterator<Freeze> it = FREEZES.values().iterator();
        while (it.hasNext()) {
            Freeze f = it.next();
            LivingEntity e = f.entity;
            if (e.isRemoved() || !e.isAlive()) {
                it.remove();
                continue;
            }
            if (now >= f.until) {
                restore(f);
                it.remove();
                continue;
            }
            if (f.hold) {
                e.setDeltaMovement(Vec3.ZERO);
                e.hurtMarked = true;
            }
            e.fallDistance = 0.0F;
        }
    }

    // ---------------------------------------------------------------- ticking

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        int now = server.getTickCount();
        runTasks(now);
        tickFreezes(now);
        tickPlayers(server, now);
    }

    private static void runTasks(int now) {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (t.runAt() <= now) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.action().run();
            } catch (Exception ex) {
                HollowBurstMod.LOGGER.error("Hollow Burst sequence step failed", ex);
            }
        }
    }

    private static void tickPlayers(MinecraftServer server, int now) {
        for (Map.Entry<UUID, PlayerState> entry : STATES.entrySet()) {
            PlayerState st = entry.getValue();
            if (st.primedUntil <= 0) continue;

            ServerPlayer p = server.getPlayerList().getPlayer(entry.getKey());
            if (p == null || !p.isAlive()) {
                st.primedUntil = 0;
                continue;
            }
            if (now > st.primedUntil) {
                st.primedUntil = 0;
                continue;
            }

            // afterimage trail while airborne
            ServerLevel l = p.serverLevel();
            Vec3 c = p.position().add(0, 0.9, 0);
            Fx.burst(l, Fx.RED, c, 2, 0.35, 0.0);
            Fx.burst(l, ParticleTypes.END_ROD, c, 1, 0.25, 0.02);

            // landing ends the window shortly after touching the ground
            if (now > st.launchTick + 10 && p.onGround() && st.graceUntil < 0) {
                st.graceUntil = now + 8;
            }
            if (st.graceUntil >= 0 && now > st.graceUntil) {
                st.primedUntil = 0;
                st.graceUntil = -1;
                st.protectUntil = now + 40;
            }
        }
    }

    // ---------------------------------------------------------------- protection and cleanup

    /** No fall or explosion damage to the player while the ability window is open. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        PlayerState st = STATES.get(p.getUUID());
        if (st == null || p.getServer() == null) return;
        int now = p.getServer().getTickCount();
        if (now > st.protectUntil && !st.sequenceActive) return;

        DamageSource src = event.getSource();
        if (src.is(DamageTypeTags.IS_FALL) || src.is(DamageTypeTags.IS_EXPLOSION)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            STATES.remove(p.getUUID());
            release(p);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            release(p);
            STATES.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        for (Freeze f : FREEZES.values()) {
            restore(f);
        }
        FREEZES.clear();
        TASKS.clear();
        STATES.clear();
    }

    // ---------------------------------------------------------------- helpers

    private static boolean isValidVictim(ServerPlayer owner, LivingEntity e) {
        if (e == owner || !e.isAlive() || e.isSpectator() || e instanceof ArmorStand) return false;
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(owner)) return false;
        return true;
    }

    private static List<LivingEntity> victimsAround(ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> isValidVictim(p, e) && e.distanceToSqr(c) <= r * r);
    }

    private static Vec3 centerOf(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    private static Vec3 horizontal(Vec3 v) {
        Vec3 h = new Vec3(v.x, 0, v.z);
        return h.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : h.normalize();
    }
}
