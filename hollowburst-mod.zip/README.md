# Hollow Burst (Forge 1.21.1)

Press **C** to detonate yourself skyward in a Gojo-style cutscene (Reversal: Red).
While airborne (20 s window, configurable):

- **Mace hit** -> *Hollow Purple* (the big one: orbs merge, time stop, huge impact)
- **Sword hit** -> *Lapse: Blue* (pull everything in, freeze, double slash)

Every cutscene has letterbox bars, typewriter subtitles, anime impact frames
(colour inversion + speed lines + star burst), zoom, roll and camera shake.

## Build
    ./gradlew build        # jar ends up in build/libs/
Needs JDK 21. Forge 52.1.0 (change `forge_version` in gradle.properties if you want a newer 52.1.x).
GitHub Actions: push this folder as the repo root, `.github/workflows/build.yml` does the rest.

## Tweak
- `config/hollowburst-common.toml`: cooldown, launch speed, damage, block destruction.
- `assets/hollowburst/lang/en_us.json`: subtitle text.
- `client/CutsceneDefs.java`: all timings, camera cuts, FOV/roll/shake curves, impact frames.
- `server/AbilityManager.java`: the gameplay side of each sequence (tick based, 20 ticks = 1 s).
- Rebind the key in Options > Controls > Hollow Burst.
